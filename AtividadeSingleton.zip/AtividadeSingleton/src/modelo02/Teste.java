package modelo02;

public class Teste {
	
	public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
                     SingletonObject inc = new SingletonObject();
                     System.out.println(inc);
        }
}

}
