package modelo.refrigerante;

public abstract class Refrigerante {

}
