package modelo.refrigerante;

public class Guarana extends Refrigerante{

}
