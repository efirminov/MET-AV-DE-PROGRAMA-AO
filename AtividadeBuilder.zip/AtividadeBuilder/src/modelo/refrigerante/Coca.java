package modelo.refrigerante;

public class Coca extends Refrigerante{

}
