package modelo.refrigerante;

public abstract class RefrigeranteBuilder {
	public abstract void pegarrefri();
	public abstract void servirrefrigerante();
	public abstract  Refrigerante getrefrigerante();
	

}
