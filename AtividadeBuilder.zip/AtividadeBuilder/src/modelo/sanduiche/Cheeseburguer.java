package modelo.sanduiche;

public class Cheeseburguer extends Sanduiche {

}
