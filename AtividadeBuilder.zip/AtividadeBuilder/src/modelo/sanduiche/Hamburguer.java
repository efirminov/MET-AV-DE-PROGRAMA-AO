package modelo.sanduiche;

public class Hamburguer extends Sanduiche{

}
