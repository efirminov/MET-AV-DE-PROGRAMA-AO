package modelo.sanduiche;

import modelo.refrigerante.RefrigeranteBuilder;

public class Servir {
	public void fazrefri(RefrigeranteBuilder builder) {
		builder.pegarrefri();
		builder.servirrefrigerante();
	}

}
