package modelo.sanduiche;

public abstract class Sanduiche {

}
