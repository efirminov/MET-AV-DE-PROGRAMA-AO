package modelo.sanduiche;

public class Cozinha {
	public void fazsanduiche(SanduicheBuilder builder) {
		builder.abrepao();
		builder.inserirIngredientes();
		builder.fecharpao();
		
		
	}
	

}
