package modelo.sanduiche;

public abstract class SanduicheBuilder {
	public abstract void abrepao();
	public abstract void inserirIngredientes();
	public abstract void fecharpao();
	public abstract void getSanduiche();
	
}
