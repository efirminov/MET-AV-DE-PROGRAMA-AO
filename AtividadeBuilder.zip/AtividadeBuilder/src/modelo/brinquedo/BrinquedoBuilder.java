package modelo.brinquedo;

public abstract class BrinquedoBuilder {
	public abstract void pegarbrinquedo();
	public abstract Brinquedo getBrinquedo();

}
