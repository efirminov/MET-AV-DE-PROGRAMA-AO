package modelo.brinquedo;

public class Boneca extends Brinquedo{

}
