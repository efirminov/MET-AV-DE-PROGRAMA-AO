package modelo.brinquedo;

public abstract class Brinquedo {

}
