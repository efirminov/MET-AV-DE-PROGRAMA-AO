package modelo.brinquedo;

public class Carro extends Brinquedo  {

}
