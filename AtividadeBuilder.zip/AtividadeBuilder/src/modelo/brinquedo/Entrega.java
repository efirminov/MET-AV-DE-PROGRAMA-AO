package modelo.brinquedo;

public class Entrega {
	public void entregabrinquedo(BrinquedoBuilder builder) {
		builder.pegarbrinquedo();
	}
	

}
