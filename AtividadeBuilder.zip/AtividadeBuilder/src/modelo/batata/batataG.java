package modelo.batata;

public class batataG extends Batata {

}
