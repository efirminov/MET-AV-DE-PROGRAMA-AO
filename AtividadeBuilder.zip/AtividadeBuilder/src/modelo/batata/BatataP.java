package modelo.batata;

public class BatataP extends Batata {

}
