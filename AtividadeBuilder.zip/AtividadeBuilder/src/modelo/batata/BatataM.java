package modelo.batata;

public class BatataM extends Batata {

}
