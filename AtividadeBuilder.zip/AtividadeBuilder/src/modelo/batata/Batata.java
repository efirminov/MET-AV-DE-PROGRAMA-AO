package modelo.batata;

public abstract class Batata {

}
