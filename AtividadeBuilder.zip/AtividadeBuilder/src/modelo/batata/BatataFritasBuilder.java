package modelo.batata;

public abstract class BatataFritasBuilder {
	public abstract void porcaopequena();
	public abstract void porcaomedia();
	public abstract void porcaogrande();
	public abstract Batata getBatata();

}
