package modelo.batata;

public class BatataFrita {
	public void fazbatata(BatataFritasBuilder builder) {
		builder.porcaopequena();
		builder.porcaomedia();
		builder.porcaogrande();
	}

}
